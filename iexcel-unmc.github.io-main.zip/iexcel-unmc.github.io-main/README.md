# 3D Pelvic Floor
### © 2022, Board of Regents of the University of Nebraska. All rights reserved.


<img src="https://github.com/iEXCEL-UNMC/iexcel-unmc.github.io/blob/b481958043f471781677377c16a7936d624cecec/3d-pelvic-floor-model.png" width="1200" alt="3d pelvic floor model">